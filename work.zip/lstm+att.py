import numpy as np
import pandas as pd
from keras.models import Model, Input
from keras.layers import LSTM, Dense, Lambda
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import matplotlib.pyplot as plt
import attention  # 加入注意力机制模块


def load_data(file_path):
    """加载并处理数据"""
    df = pd.read_csv(file_path)
    data = df.iloc[:, 2:9].astype('float32')
    return data


def split_sequences(sequences, n_steps_in, n_steps_out):
    """拆分序列为输入和输出"""
    X, y = list(), list()
    for i in range(len(sequences)):
        end_ix = i + n_steps_in
        out_end_ix = end_ix + n_steps_out
        if out_end_ix > len(sequences):
            break
        seq_x, seq_y = sequences[i:end_ix, :], sequences[end_ix, 3]  # 预测close列
        X.append(seq_x)
        y.append(seq_y)
    return np.array(X), np.array(y)


def normalize_data(data):
    """归一化数据"""
    scaler = MinMaxScaler(feature_range=(-1, 1))
    scaled_data = scaler.fit_transform(data)
    return scaled_data, scaler


def build_model(input_shape, n_steps_in, n_features):
    """构建带有注意力机制的LSTM模型"""
    inputs = Input(shape=input_shape)

    # 注意力机制
    hidden_1 = attention.attention_block_2(inputs, feature_cnt=n_steps_in, dim=n_features, names='steps_attention')
    att_out = Lambda(lambda x: x * 0.5, name='gru_input')(hidden_1)

    gru_1 = LSTM(4, return_sequences=True, activation='relu')(att_out)
    gru_2 = LSTM(8, return_sequences=False, activation='relu')(gru_1)

    dense_1_1 = Dense(50, activation='relu', name="dense_1_1")(gru_2)
    output = Dense(units=1, name='output')(dense_1_1)

    model = Model(inputs=inputs, outputs=output)
    model.compile(loss='mse', optimizer='adam', metrics=['mse'])

    return model


def train_model(model, train_data, train_label, val_data, val_label, batch_size=30, epochs=200):
    """训练模型"""
    history = model.fit(train_data, train_label, validation_data=(val_data, val_label),
                        batch_size=batch_size, epochs=epochs, verbose=1)
    return history


def inverse_transform(predictions, scaler, original_data_shape):
    """逆归一化处理"""
    temp = np.zeros((predictions.shape[0], original_data_shape[1]))
    temp[:, 0] = predictions.flatten()  # 将预测值放入第0列
    return scaler.inverse_transform(temp)


def evaluate_model(y_real, y_predict):
    """评估模型"""
    rmse = np.sqrt(mean_squared_error(y_predict, y_real))
    mae = mean_absolute_error(y_predict, y_real)
    r2 = r2_score(y_predict, y_real)
    print(f'Test RMSE: {rmse:.5f}, Test MAE: {mae:.5f}, Test R2: {r2:.5f}')


def plot_results(y_real, y_predict):
    """绘制预测结果"""
    plt.plot(y_real, label='Original')
    plt.plot(y_predict, label='Predict')
    plt.title('Time_Att-LSTM')
    plt.xlabel('Data', fontsize='10')
    plt.ylabel('Predict Value', fontsize='10')
    plt.legend()
    plt.show()


def plot_loss(history):
    """绘制训练和验证集损失图"""
    plt.plot(history.history['loss'], label='Train Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.title('Training and Validation Loss')
    plt.xlabel('Epochs')
    plt.ylabel('Loss')
    plt.legend()
    plt.show()


def config():
    """配置函数，管理所有参数"""
    config_params = {
        'file_path': 'stock_data.csv',  # 数据文件路径
        'n_steps_in': 10,  # 输入步数
        'n_steps_out': 1,  # 输出步数
        'test_num': 100,  # 测试集大小
        'batch_size': 30,  # 批次大小
        'epochs': 50  # 训练轮数
    }
    return config_params


def main():
    """主函数"""
    # 加载配置
    cfg = config()

    # 加载并处理数据
    data = load_data(cfg['file_path'])

    # 归一化数据
    scaled_dataset, scaler = normalize_data(data)

    # 拆分序列
    X, y = split_sequences(scaled_dataset, cfg['n_steps_in'], cfg['n_steps_out'])

    # 划分训练和测试数据
    train_data = X[:-cfg['test_num'], :]
    train_label = y[:-cfg['test_num']]
    test_data = X[-cfg['test_num']:, :]
    test_label = y[-cfg['test_num']:]

    # 划分训练和验证数据
    val_size = int(0.2 * len(train_data))  # 20% 的数据作为验证集
    val_data = train_data[-val_size:]
    val_label = train_label[-val_size:]
    train_data = train_data[:-val_size]
    train_label = train_label[:-val_size]

    # 构建模型
    model = build_model(input_shape=(cfg['n_steps_in'], X.shape[2]),
                        n_steps_in=cfg['n_steps_in'], n_features=X.shape[2])

    # 训练模型
    history = train_model(model, train_data, train_label, val_data, val_label,
                          batch_size=cfg['batch_size'], epochs=cfg['epochs'])

    # 预测
    yhat = model.predict(test_data)
    y_real = test_label.reshape((len(test_label), 1))

    # 逆归一化
    yhat_inverse = inverse_transform(yhat, scaler, scaled_dataset.shape)
    y_real_inverse = inverse_transform(y_real, scaler, scaled_dataset.shape)

    # 评估模型
    evaluate_model(y_real_inverse[:, 0], yhat_inverse[:, 0])

    # 绘制结果
    plot_results(y_real_inverse[:, 0], yhat_inverse[:, 0])

    # 绘制损失图
    plot_loss(history)


if __name__ == '__main__':
    main()
