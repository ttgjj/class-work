"""
author:chenshun
date:2020/8/21 16:43
content: 构建attention模块
"""

from keras.layers import Dense, Permute, RepeatVector, Reshape, Activation
from keras.layers import Multiply, Lambda, Flatten
import keras.backend as K


def attention_block_1(inputs, feature_cnt, dim, only_prob_out=False):
    h_block = int(feature_cnt * dim / 32 / 2)

    hidden = Flatten()(inputs)
    while (h_block >= 1):
        h_dim = h_block * 32
        hidden = Dense(h_dim, activation='selu', use_bias=True)(hidden)
        h_block = int(h_block / 2)

    attention = Dense(feature_cnt, activation='softmax', name='attention')(hidden)

    if only_prob_out:
        return attention

    else:

        attention = RepeatVector(dim)(attention)
        attention = Permute(dims=(2, 1))(attention)

        attention_out = Multiply()([attention, inputs])
        return attention_out

def attention_block_2(inputs,feature_cnt,dim, only_prob_out=False, names='attention'):

    a = Permute((2, 1))(inputs)

    a = Dense(feature_cnt, activation='softmax', name=names+'_calculate')(a)

    a = Lambda(lambda x: K.mean(x, axis=1), name=names)(a)

    if only_prob_out:

        return a

    else:
        a = RepeatVector(dim)(a)

        a_probs = Permute((2, 1), name=names+'_vec')(a)
        attention_out = Multiply()([inputs, a_probs])

        return attention_out


def attention_block_3(inputs,feature_cnt,dim, only_prob_out=False):
    a = Flatten()(inputs)

    a = Dense(feature_cnt*dim, activation='softmax')(a)

    a = Reshape((feature_cnt, dim))(a)

    a = Lambda(lambda x: K.sum(x, axis=2), name='attention')(a)

    if only_prob_out:

        return a

    else:

        a = RepeatVector(dim)(a)

        a_probs = Permute((2, 1), name='attention_vec')(a)

        attention_out = Multiply()([inputs, a_probs])

        return attention_out


def attention_block_4(inputs,feature_cnt,dim, only_prob_out=False, names='attention'):

    a = Permute((2, 1))(inputs)

    a = Dense(feature_cnt, activation='tanh', name=names+'_calculate')(a)
    a = Activation(K.softmax)(a)

    a = Lambda(lambda x: K.mean(x, axis=1), name=names)(a)

    if only_prob_out:

        return a

    else:
        a = RepeatVector(dim)(a)

        a_probs = Permute((2, 1), name=names+'_vec')(a)
        attention_out = Multiply()([inputs, a_probs])

        return attention_out

