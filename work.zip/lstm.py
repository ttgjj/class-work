import numpy as np
import pandas as pd
from keras.models import Model, Input
from keras.layers import LSTM, Dense
from keras.callbacks import EarlyStopping
from sklearn.preprocessing import MinMaxScaler
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import matplotlib.pyplot as plt


def config():
    """配置超参数"""
    params = {
        'file_path': 'stock_data.csv',
        'n_steps_in': 10,
        'n_steps_out': 1,
        'batch_size': 32,
        'epochs': 50,
        'lstm_units_1': 4,
        'lstm_units_2': 8
    }
    return params


def load_data(file_path):
    """加载数据"""
    df = pd.read_csv(file_path)
    data = df.iloc[:, 2:9].astype('float32')
    return data


def split_sequences(sequences, n_steps_in, n_steps_out):
    """拆分序列为输入和输出"""
    X, y = list(), list()
    for i in range(len(sequences)):
        end_ix = i + n_steps_in
        out_end_ix = end_ix + n_steps_out
        if out_end_ix > len(sequences):
            break
        seq_x, seq_y = sequences[i:end_ix, :], sequences[end_ix, 3]  # 预测close列
        X.append(seq_x)
        y.append(seq_y)
    return np.array(X), np.array(y)


def normalize_data(data):
    """归一化数据"""
    scaler = MinMaxScaler(feature_range=(-1, 1))
    scaled_data = scaler.fit_transform(data)
    return scaled_data, scaler


def build_model(input_shape, lstm_units_1=4, lstm_units_2=8):
    """构建LSTM模型"""
    inputs = Input(shape=input_shape)
    gru_1 = LSTM(lstm_units_1, return_sequences=True, activation='relu')(inputs)
    gru_2 = LSTM(lstm_units_2, return_sequences=False, activation='relu')(gru_1)
    dense_1_1 = Dense(50, activation='relu', name="dense_1_1")(gru_2)
    output = Dense(units=1, name='output')(dense_1_1)
    model = Model(inputs=inputs, outputs=output)
    model.compile(loss='mse', optimizer='adam', metrics=['mae'])
    return model


def train_model(model, train_data, train_label, batch_size=30, epochs=100):
    """训练模型"""
    early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
    history = model.fit(train_data, train_label,
                        batch_size=batch_size,
                        epochs=epochs,
                        verbose=1,
                        validation_split=0.1,  # 使用 10% 的数据作为验证集
                        callbacks=[early_stopping])  # 添加 EarlyStopping
    return history


def plot_loss(history):
    """绘制损失图"""
    plt.plot(history.history['loss'], label='Train Loss')
    plt.plot(history.history['val_loss'], label='Validation Loss')
    plt.title('Model Loss')
    plt.xlabel('Epoch')
    plt.ylabel('Loss')
    plt.legend()
    plt.show()


def inverse_transform(predictions, scaler):
    """逆归一化"""
    yhat_tem = np.zeros((predictions.shape[0], scaler.scale_.shape[0]))
    yhat_tem[:, 0] = predictions.flatten()  # Fill the first column with predictions
    return scaler.inverse_transform(yhat_tem)


def evaluate_model(y_real, y_predict):
    """评估模型"""
    rmse = np.sqrt(mean_squared_error(y_predict, y_real))
    mae = mean_absolute_error(y_predict, y_real)
    r2 = r2_score(y_predict, y_real)
    print('Test RMSE: %.5f' % rmse, 'Test MAE: %.5f' % mae, 'Test R2: %.5f' % r2)


def plot_results(y_real, y_predict):
    """绘制结果图"""
    plt.plot(y_real, label='True')
    plt.plot(y_predict, label='Predict')
    plt.title('LSTM')
    plt.xlabel('Day', fontsize='10')
    plt.ylabel('Price', fontsize='10')
    # 去掉标签的边框
    plt.legend(frameon=False)
    plt.show()


def main():
    """主函数"""
    params = config()  # 获取配置参数
    data = load_data(params['file_path'])
    scaled_dataset, scaler = normalize_data(data)

    X, y = split_sequences(scaled_dataset, params['n_steps_in'], params['n_steps_out'])

    # Set train data and test data
    test_num = 100
    train_data = X[:-test_num, :]
    train_label = y[:-test_num]
    test_data = X[-test_num:, :]
    test_label = y[-test_num:]

    model = build_model(input_shape=(params['n_steps_in'], X.shape[2]),
                        lstm_units_1=params['lstm_units_1'],
                        lstm_units_2=params['lstm_units_2'])

    history = train_model(model, train_data, train_label,
                          batch_size=params['batch_size'],
                          epochs=params['epochs'])

    yhat = model.predict(test_data)
    y_real = test_label.reshape((len(test_label), 1))

    # Inverse scaling
    yhat = inverse_transform(yhat, scaler)
    y_real = inverse_transform(y_real, scaler)

    # Evaluate model
    evaluate_model(y_real[:, 0], yhat[:, 0])

    # Plot loss and results
    plot_loss(history)
    plot_results(y_real[:, 0], yhat[:, 0])


if __name__ == '__main__':
    main()
